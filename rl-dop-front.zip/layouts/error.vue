<template>
  <div class="errorPage">
    <b-container>
      <h1>Error 404</h1>
      <h2>Oooops! Page Not Found</h2>
    </b-container>
  </div>
</template>

<style lang="sass">
.errorPage
  padding: 100px 0
  h1
    margin-bottom: 15px
</style>
