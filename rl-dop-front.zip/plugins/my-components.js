import Vue from 'vue'
import MyInput from '../components/Input.vue'

Vue.component('MyInput', MyInput)
