import Vue from 'vue'
import circleBar from 'vue-circle-counter'

Vue.component('circleBar', circleBar)
