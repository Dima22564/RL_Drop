import Vue from 'vue'
import slick from 'vue-slick'

Vue.use(slick)
Vue.component('slick', slick)
