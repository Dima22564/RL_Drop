import Vue from 'vue'
import Vuebar from 'vuebar'
import { ToastPlugin } from 'bootstrap-vue'

Vue.use(ToastPlugin)
Vue.use(Vuebar)
