import Vue from 'vue'
import vue2Dropzone from 'vue2-dropzone'

Vue.component('vueDropzone', vue2Dropzone)
