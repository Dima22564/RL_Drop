<template>
  <div></div>
</template>

<script>
export default {
  layout: 'admin'
}
</script>
